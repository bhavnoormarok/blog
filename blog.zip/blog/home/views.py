from django.shortcuts import render, HttpResponse
from django.shortcuts import redirect
from django.contrib.auth.forms import  User, UserCreationForm
from django.contrib.auth import  authenticate, login, logout
from .models import Post
from django.views.generic import TemplateView
from .form import contentform
from .registration import registration

# Create your views here.
def home(request):
    if request.method=='GET':
        allpost=Post.objects.all()
        l=[]
        r=len(allpost)
        for i in range(r):
            l.append(allpost[r-i-1])
        return render(request, 'login.html', {'allpost': l})
    else :
        user=authenticate(username= request.POST['Username'], password= request.POST['Password'])
        if user is not None:
            login(request, user)
            return redirect('dashboard/')
        else:
            return HttpResponse('error')
    

def log_out(request):
    logout(request)
    return redirect('/login/')

def signup(request):
    if request.method=='POST':
        form=registration(request.POST)
        if form.is_valid():
            form.save()
            return redirect('/login/')
        else:
            return HttpResponse("error")
    else:
        form=registration()
        allpost=Post.objects.all()
        # allpost='bhavnoor'
        l=[]
        r=len(allpost)
        for i in range(r):
            l.append(allpost[r-i-1])
        names=['Username', 'First Name', 'Last Name', 'Email', 'Password', 'Repeat Password' ]
        z=zip(form,names)
        return render(request, 'form.html',{'allpost':l, 'z':z})

class dashboard(TemplateView):
    template_name='dashboard.html'
    def get(self, request):
        form=contentform()
        allpost=list(filter(lambda x:x.sender==request.user.username ,Post.objects.all()))
        l=[]
        r=len(allpost)
        for i in range(r):
            l.append(allpost[r-i-1])
        names=['Title', 'Content']
        z=zip(contentform(), names)
        return render(request, self.template_name, {'z':z, 'allpost': l})
    
    def post(self, request):
        form=contentform(request.POST)
        if form.is_valid:
            post=form.save(commit=False)
            post.sender=request.user
            post.save()
            return redirect('/login/dashboard')

def red(request):
    return redirect('/login/')



        

    
    
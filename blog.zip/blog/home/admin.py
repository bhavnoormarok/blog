from django.contrib import admin
from home.models import dashboard, Post

# Register your models here.
admin.site.register(Post)
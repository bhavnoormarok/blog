from django import forms
from .models import Post

class contentform(forms.ModelForm):
    title=forms.CharField(widget=forms.TextInput(attrs={'class':'input100'}))
    post=forms.CharField(widget=forms.TextInput(attrs={'class':'input100'}))

    class Meta:
        model=Post 
        fields=('title','post')
from django.db import models
from django.contrib.auth.models import User
from django.db.models.signals import post_save


class Post(models.Model):
    sender=models.CharField(max_length=50)
    title=models.TextField(max_length=200)
    post=models.TextField(max_length=2000)

class dashboard(models.Model):
    user= models.OneToOneField(User, on_delete=models.CASCADE)

def newuser(sender, **kwargs):
    if kwargs['created']:
        profile= dashboard.objects.create(user=kwargs['instance'])

post_save.connect(newuser, sender=User)
